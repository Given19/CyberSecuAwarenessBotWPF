﻿using System;
using System.Collections.Generic;
using CyberSecuAwarenessBotWPF.Models;

namespace CyberSecuAwarenessBotWPF.Services
{
    public class QuizService
    {
        private List<QuizQuestion> _questions;
        private int _currentIndex;
        private int _score;
        private Random _random = new Random();

        public int TotalQuestions => _questions.Count;
        public int CurrentIndex => _currentIndex;
        public int Score => _score;
        public bool IsFinished => _currentIndex >= _questions.Count;

        public QuizService() { InitQuiz(); }

        public QuizQuestion GetCurrentQuestion() =>
            IsFinished ? null : _questions[_currentIndex];

        public string GetCurrentExplanation()
        {
            if (_currentIndex == 0) return string.Empty;
            return _questions[_currentIndex - 1].Explanation;
        }

        public bool SubmitAnswer(int answerIndex)
        {
            if (IsFinished) return false;
            bool correct = answerIndex == _questions[_currentIndex].CorrectIndex;
            if (correct) _score++;
            _currentIndex++;
            return correct;
        }

        public string GetFeedback()
        {
            int pct = (int)((_score / (double)TotalQuestions) * 100);
            if (pct >= 80) return string.Format("Excellent! You scored {0}/{1} ({2}%). You are a cybersecurity pro!", _score, TotalQuestions, pct);
            if (pct >= 60) return string.Format("Good job! You scored {0}/{1} ({2}%). Keep learning to stay safe online!", _score, TotalQuestions, pct);
            return string.Format("You scored {0}/{1} ({2}%). Keep studying cybersecurity to stay safe online!", _score, TotalQuestions, pct);
        }

        public void Reset() { InitQuiz(); }

        private void InitQuiz()
        {
            _questions = BuildQuestions();
            Shuffle(_questions);
            _questions = _questions.GetRange(0, Math.Min(10, _questions.Count));
            _currentIndex = 0;
            _score = 0;
        }

        private void Shuffle(List<QuizQuestion> list)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = _random.Next(i + 1);
                var tmp = list[i]; list[i] = list[j]; list[j] = tmp;
            }
        }

        private List<QuizQuestion> BuildQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion {
                    Question = "What should you do if you receive an email asking for your password?",
                    Options = new List<string> { "Reply with your password", "Delete the email", "Report it as phishing", "Ignore it" },
                    CorrectIndex = 2,
                    Explanation = "Always report phishing emails. Legitimate organisations never ask for your password via email.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "True or False: You should use the same password for all your accounts.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Never reuse passwords. If one account is compromised, all others become vulnerable.",
                    Type = QuestionType.TrueFalse
                },
                new QuizQuestion {
                    Question = "What does 2FA stand for?",
                    Options = new List<string> { "Two Factor Authentication", "Two File Access", "Transfer File Authority", "Two Form Authorisation" },
                    CorrectIndex = 0,
                    Explanation = "2FA stands for Two Factor Authentication — it adds a second layer of security to your accounts.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "True or False: Public Wi-Fi is safe to use for online banking.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Public Wi-Fi is unencrypted. Always use a VPN when accessing sensitive accounts on public networks.",
                    Type = QuestionType.TrueFalse
                },
                new QuizQuestion {
                    Question = "Which of the following is the strongest password?",
                    Options = new List<string> { "password123", "MyName2000", "P@ssw0rd!", "xK9#mL2$vQ8!" },
                    CorrectIndex = 3,
                    Explanation = "A strong password uses a mix of uppercase, lowercase, numbers, and symbols with no dictionary words.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "What is malware?",
                    Options = new List<string> { "A type of firewall", "Software designed to harm your device", "A secure browser", "An antivirus program" },
                    CorrectIndex = 1,
                    Explanation = "Malware is malicious software designed to damage, disrupt, or gain unauthorised access to systems.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "True or False: A VPN hides your internet traffic from hackers on public Wi-Fi.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 0,
                    Explanation = "A VPN encrypts your traffic, protecting it from eavesdroppers on public networks.",
                    Type = QuestionType.TrueFalse
                },
                new QuizQuestion {
                    Question = "What is social engineering in cybersecurity?",
                    Options = new List<string> { "Building social media apps", "Manipulating people to reveal information", "Engineering social networks", "Creating user profiles" },
                    CorrectIndex = 1,
                    Explanation = "Social engineering manipulates people psychologically to reveal confidential information.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "True or False: You should update your software regularly to stay secure.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 0,
                    Explanation = "Software updates patch security vulnerabilities that hackers exploit. Always keep your software up to date.",
                    Type = QuestionType.TrueFalse
                },
                new QuizQuestion {
                    Question = "What is phishing?",
                    Options = new List<string> { "A type of malware", "Sending fake emails to steal information", "Hacking into a network", "Stealing physical devices" },
                    CorrectIndex = 1,
                    Explanation = "Phishing involves sending deceptive emails that appear legitimate to trick users into revealing sensitive information.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "SCENARIO: You receive an email saying 'Your account will be suspended! Click HERE immediately to verify!' What type of attack is this?",
                    Options = new List<string> { "Ransomware attack", "Phishing attack", "Brute force attack", "Man-in-the-middle attack" },
                    CorrectIndex = 1,
                    Explanation = "This is a classic phishing attack. It creates urgency and fear to trick you into clicking a malicious link.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "SCENARIO: Someone calls claiming to be from Microsoft saying your computer has a virus. What should you do?",
                    Options = new List<string> { "Give them remote access", "Pay them to fix it", "Hang up — this is a scam", "Give them your password" },
                    CorrectIndex = 2,
                    Explanation = "This is a tech-support scam. Microsoft never calls you unsolicited. Hang up immediately.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "DIAGRAM: A hacker intercepts communication between your browser and a website:\n[You] <---> [Hacker] <---> [Website]\nWhat attack is this?",
                    Options = new List<string> { "Phishing", "Ransomware", "Man-in-the-Middle attack", "Brute Force attack" },
                    CorrectIndex = 2,
                    Explanation = "A Man-in-the-Middle (MitM) attack intercepts communications between two parties. HTTPS and VPNs help prevent this.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "SCENARIO: Your friend sends you a message 'Win a free iPhone! Click now!' What should you do?",
                    Options = new List<string> { "Click the link immediately", "Share it with friends", "Ignore it and warn your friend their account may be hacked", "Enter your details to claim the prize" },
                    CorrectIndex = 2,
                    Explanation = "This is a social engineering scam. Your friend's account may be compromised. Never click suspicious links.",
                    Type = QuestionType.MultipleChoice
                },
                new QuizQuestion {
                    Question = "True or False: Free VPNs are always the best choice for privacy.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Free VPNs often sell your data to third parties. Always use a reputable paid VPN with a no-logs policy.",
                    Type = QuestionType.TrueFalse
                },
            };
        }
    }
}