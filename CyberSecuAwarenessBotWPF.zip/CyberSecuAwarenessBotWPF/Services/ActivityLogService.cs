﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberSecuAwarenessBotWPF.Services
{
    public class ActivityLogService
    {
        private readonly List<string> _log = new List<string>();
        private const int MaxEntries = 10;

        public void Log(string action)
        {
            string entry = string.Format("[{0}] {1}", DateTime.Now.ToString("HH:mm"), action);
            _log.Add(entry);
            if (_log.Count > MaxEntries * 2)
                _log.RemoveRange(0, _log.Count - MaxEntries);
        }

        public List<string> GetRecentLogs(int count = 10) =>
            _log.Skip(Math.Max(0, _log.Count - count)).ToList();

        public string GetLogSummary()
        {
            var recent = GetRecentLogs();
            if (recent.Count == 0)
                return "No activity recorded yet. Start chatting to see your activity log!";
            var sb = new System.Text.StringBuilder("Here is a summary of recent actions:\n\n");
            for (int i = 0; i < recent.Count; i++)
                sb.AppendLine(string.Format("{0}. {1}", i + 1, recent[i]));
            return sb.ToString().Trim();
        }

        public int GetLogCount() => _log.Count;
    }
}