﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using CyberSecuAwarenessBotWPF.Models;

namespace CyberSecuAwarenessBotWPF.Services
{
    public class TaskService
    {
        private List<TaskItem> _tasks = new List<TaskItem>();
        private int _nextId = 1;
        private readonly string _filePath;

        public TaskService()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string folder = Path.Combine(appData, "CyberGuard");
            Directory.CreateDirectory(folder);
            _filePath = Path.Combine(folder, "tasks.json");
            LoadTasks();
        }

        public List<TaskItem> GetAllTasks() => _tasks.ToList();
        public List<TaskItem> GetPendingTasks() => _tasks.Where(t => !t.IsCompleted).ToList();
        public int GetTaskCount() => _tasks.Count;
        public int GetPendingCount() => _tasks.Count(t => !t.IsCompleted);

        public TaskItem AddTask(string title, string description = "", string reminder = "", DateTime? reminderDate = null)
        {
            var task = new TaskItem
            {
                Id = _nextId++,
                Title = title,
                Description = description,
                Reminder = reminder,
                ReminderDate = reminderDate,
                IsCompleted = false,
                CreatedAt = DateTime.Now
            };
            _tasks.Add(task);
            SaveTasks();
            return task;
        }

        public bool CompleteTask(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return false;
            task.IsCompleted = true;
            SaveTasks();
            return true;
        }

        public bool DeleteTask(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return false;
            _tasks.Remove(task);
            SaveTasks();
            return true;
        }

        private void SaveTasks()
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("[");
                for (int i = 0; i < _tasks.Count; i++)
                {
                    var t = _tasks[i];
                    sb.Append("{");
                    sb.AppendFormat("\"Id\":{0},", t.Id);
                    sb.AppendFormat("\"Title\":\"{0}\",", Escape(t.Title));
                    sb.AppendFormat("\"Description\":\"{0}\",", Escape(t.Description));
                    sb.AppendFormat("\"Reminder\":\"{0}\",", Escape(t.Reminder));
                    sb.AppendFormat("\"ReminderDate\":\"{0}\",", t.ReminderDate?.ToString("o") ?? "");
                    sb.AppendFormat("\"IsCompleted\":{0},", t.IsCompleted.ToString().ToLower());
                    sb.AppendFormat("\"CreatedAt\":\"{0}\"", t.CreatedAt.ToString("o"));
                    sb.Append("}");
                    if (i < _tasks.Count - 1) sb.Append(",");
                }
                sb.Append("]");
                File.WriteAllText(_filePath, sb.ToString());
            }
            catch { }
        }

        private void LoadTasks()
        {
            try
            {
                if (!File.Exists(_filePath)) return;
                string json = File.ReadAllText(_filePath);
                _tasks = ParseTasksFromJson(json);
                if (_tasks.Count > 0)
                    _nextId = _tasks.Max(t => t.Id) + 1;
            }
            catch { _tasks = new List<TaskItem>(); }
        }

        private List<TaskItem> ParseTasksFromJson(string json)
        {
            var result = new List<TaskItem>();
            json = json.Trim();
            if (json == "[]" || string.IsNullOrEmpty(json)) return result;
            json = json.TrimStart('[').TrimEnd(']');
            var objects = SplitJsonObjects(json);
            foreach (var obj in objects)
            {
                try
                {
                    var task = new TaskItem();
                    task.Id = int.Parse(GetJsonValue(obj, "Id"));
                    task.Title = GetJsonValue(obj, "Title");
                    task.Description = GetJsonValue(obj, "Description");
                    task.Reminder = GetJsonValue(obj, "Reminder");
                    task.IsCompleted = GetJsonValue(obj, "IsCompleted") == "true";
                    string createdAt = GetJsonValue(obj, "CreatedAt");
                    if (!string.IsNullOrEmpty(createdAt)) task.CreatedAt = DateTime.Parse(createdAt);
                    string reminderDate = GetJsonValue(obj, "ReminderDate");
                    if (!string.IsNullOrEmpty(reminderDate)) task.ReminderDate = DateTime.Parse(reminderDate);
                    result.Add(task);
                }
                catch { }
            }
            return result;
        }

        private List<string> SplitJsonObjects(string json)
        {
            var objects = new List<string>();
            int depth = 0, start = 0;
            for (int i = 0; i < json.Length; i++)
            {
                if (json[i] == '{') { if (depth == 0) start = i; depth++; }
                else if (json[i] == '}') { depth--; if (depth == 0) objects.Add(json.Substring(start, i - start + 1)); }
            }
            return objects;
        }

        private string GetJsonValue(string json, string key)
        {
            string search = "\"" + key + "\":";
            int idx = json.IndexOf(search);
            if (idx < 0) return string.Empty;
            int start = idx + search.Length;
            if (start >= json.Length) return string.Empty;
            if (json[start] == '"')
            {
                int end = json.IndexOf('"', start + 1);
                return end < 0 ? string.Empty : json.Substring(start + 1, end - start - 1);
            }
            else
            {
                int end = json.IndexOfAny(new[] { ',', '}' }, start);
                return end < 0 ? json.Substring(start) : json.Substring(start, end - start);
            }
        }

        private string Escape(string s) =>
            string.IsNullOrEmpty(s) ? string.Empty : s.Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}