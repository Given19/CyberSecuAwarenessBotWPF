﻿using System;

namespace CyberSecuAwarenessBotWPF.Models
{
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Reminder { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; }

        public TaskItem()
        {
            CreatedAt = DateTime.Now;
            IsCompleted = false;
            Reminder = string.Empty;
            Description = string.Empty;
            Title = string.Empty;
        }
    }
}