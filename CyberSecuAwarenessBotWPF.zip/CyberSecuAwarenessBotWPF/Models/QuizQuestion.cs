﻿using System.Collections.Generic;

namespace CyberSecuAwarenessBotWPF.Models
{
    public enum QuestionType { MultipleChoice, TrueFalse }

    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public int CorrectIndex { get; set; }
        public string Explanation { get; set; }
        public QuestionType Type { get; set; }

        public QuizQuestion()
        {
            Options = new List<string>();
            Question = string.Empty;
            Explanation = string.Empty;
        }
    }
}