﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using CyberSecuAwarenessBotWPF.Services;
using CyberSecuAwarenessBotWPF.UI;
using CyberSecuAwarenessBotWPF.Views;

namespace CyberSecuAwarenessBotWPF
{
    public partial class MainWindow : Window, IDisposable
    {
        private readonly ChatbotService _engine = new ChatbotService();
        private readonly AudioPlayer _voice = new AudioPlayer();
        private readonly TaskService _taskService = new TaskService();
        private readonly ActivityLogService _logService = new ActivityLogService();
        private bool _voiceEnabled = true;
        private bool _disposed;
        private bool _awaitingTaskTitle = false;
        private bool _awaitingTaskReminder = false;
        private string _pendingTaskTitle = string.Empty;
        private string _pendingTaskDescription = string.Empty;

        private const string AsciiArt = "CyberGuard";

        public MainWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            AsciiArtBlock.Text = AsciiArt;

            foreach (string topic in _engine.AvailableTopics)
            {
                var btn = new Button
                {
                    Content = topic,
                    Style = (Style)FindResource("CyberButtonSecondary"),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Margin = new Thickness(0, 0, 0, 4)
                };
                string t = topic;
                btn.Click += (s, args) => SendMessage(t);
                QuickTopicsPanel.Children.Add(btn);
            }

            _engine.OnSentimentDetected += OnSentimentDetected;
            _voice.SpeakGreeting(string.Empty);
            _logService.Log("CyberGuard started");

            AppendBotMessage(
                "Welcome to CyberGuard — your cybersecurity awareness assistant!\n\n" +
                "I can help you understand:\n" +
                "- Password security\n- Phishing and email scams\n" +
                "- Online privacy\n- Scam detection\n" +
                "- Malware and viruses\n- Wi-Fi security\n\n" +
                "New in Part 3:\n" +
                "- Type 'add task' to manage cybersecurity tasks\n" +
                "- Type 'quiz' to test your cybersecurity knowledge\n" +
                "- Type 'activity log' to see recent actions\n\n" +
                "Tell me your name to get started!");

            InputBox.Focus();
        }

        private void OpenTaskWindow()
        {
            _logService.Log("Task Assistant opened");
            var win = new TaskWindow(_taskService, _logService);
            win.Owner = this;
            win.ShowDialog();
            UpdateSidebarDirect();
        }

        private void OpenQuizWindow()
        {
            _logService.Log("Quiz opened");
            var win = new QuizWindow(_logService);
            win.Owner = this;
            win.ShowDialog();
        }

        private void ShowActivityLog()
        {
            string log = _logService.GetLogSummary();
            AppendBotMessage("Activity Log:\n\n" + log);
            _logService.Log("Activity log viewed");
        }

        private void BtnTaskAssistant_Click(object sender, RoutedEventArgs e) => OpenTaskWindow();
        private void BtnQuiz_Click(object sender, RoutedEventArgs e) => OpenQuizWindow();
        private void BtnActivityLog_Click(object sender, RoutedEventArgs e) => ShowActivityLog();
        private void BtnSend_Click(object sender, RoutedEventArgs e) => SendMessage(InputBox.Text);

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !string.IsNullOrWhiteSpace(InputBox.Text))
                SendMessage(InputBox.Text);
        }

        private void SendMessage(string text)
        {
            text = text.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;

            AppendUserMessage(text);
            InputBox.Clear();
            ConsoleUI.ShowStatus(StatusBar, "CyberGuard is thinking...");

            string lower = text.ToLower();

            if (_awaitingTaskTitle)
            {
                _awaitingTaskTitle = false;
                _pendingTaskTitle = text;
                _awaitingTaskReminder = true;
                AppendBotMessage(string.Format("Got it! Task: {0}\n\nWould you like to add a reminder? Type something like 'Remind me in 3 days' or type 'no' to skip.", text));
                _logService.Log(string.Format("Task title entered: '{0}'", text));
                ConsoleUI.ShowStatus(StatusBar, "Ready.");
                return;
            }

            if (_awaitingTaskReminder)
            {
                _awaitingTaskReminder = false;
                string reminder = string.Empty;
                DateTime? reminderDate = null;

                if (lower != "no" && lower != "skip" && lower != "none")
                {
                    reminder = text;
                    if (lower.Contains("tomorrow"))
                        reminderDate = DateTime.Now.AddDays(1);
                    else if (lower.Contains("week"))
                        reminderDate = DateTime.Now.AddDays(7);
                    else
                        for (int d = 1; d <= 30; d++)
                            if (lower.Contains(d + " day"))
                            { reminderDate = DateTime.Now.AddDays(d); break; }
                }

                var task = _taskService.AddTask(_pendingTaskTitle, _pendingTaskDescription, reminder, reminderDate);
                _logService.Log(string.Format("Task added: '{0}'", task.Title));
                if (reminderDate.HasValue)
                    _logService.Log(string.Format("Reminder set for '{0}' on {1}", task.Title, reminderDate.Value.ToShortDateString()));

                string response = string.Format("Task '{0}' added successfully!", task.Title);
                if (reminderDate.HasValue)
                    response += string.Format("\nReminder set for: {0}", reminderDate.Value.ToShortDateString());
                response += string.Format("\n\nYou now have {0} pending tasks. Type 'show tasks' to view all.", _taskService.GetPendingCount());

                AppendBotMessage(response);
                ConsoleUI.ShowStatus(StatusBar, "Ready.");
                return;
            }

            string nlpResponse = ProcessNLP(lower, text);
            if (nlpResponse != null)
            {
                AppendBotMessage(nlpResponse);
                ConsoleUI.ShowStatus(StatusBar, "Ready.");
                if (_voiceEnabled) _voice.SpeakAsync(nlpResponse);
                return;
            }

            Task.Run(() => _engine.ProcessInput(text))
                .ContinueWith(t =>
                {
                    string response = t.Result;
                    AppendBotMessage(response);
                    UpdateSidebarDirect();
                    ConsoleUI.ShowStatus(StatusBar, "Ready.");
                    if (_voiceEnabled) _voice.SpeakAsync(response);
                }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private string ProcessNLP(string lower, string original)
        {
            if (lower.Contains("add task") || lower.Contains("new task") ||
                lower.Contains("create task") || lower.Contains("add a task"))
            {
                _logService.Log("Task creation initiated via NLP");
                string taskTitle = ExtractAfterKeyword(lower, original,
                    new[] { "add task", "new task", "create task", "add a task" });

                if (!string.IsNullOrEmpty(taskTitle))
                {
                    _awaitingTaskReminder = true;
                    _pendingTaskTitle = taskTitle;
                    _pendingTaskDescription = string.Empty;
                    return string.Format("Task '{0}' noted! Would you like to add a reminder? Type 'Remind me in 3 days' or 'no' to skip.", taskTitle);
                }
                else
                {
                    _awaitingTaskTitle = true;
                    return "Sure! What is the title of the task you want to add?";
                }
            }

            if (lower.Contains("show tasks") || lower.Contains("view tasks") ||
                lower.Contains("my tasks") || lower.Contains("list tasks"))
            {
                _logService.Log("Tasks viewed via chat");
                var tasks = _taskService.GetAllTasks();
                if (tasks.Count == 0)
                    return "You have no tasks yet! Type 'add task' to create one.";
                var sb = new System.Text.StringBuilder("Here are your tasks:\n\n");
                foreach (var task in tasks)
                {
                    string status = task.IsCompleted ? "Done" : "Pending";
                    sb.AppendLine(string.Format("- {0} [{1}]", task.Title, status));
                    if (!string.IsNullOrEmpty(task.Reminder))
                        sb.AppendLine(string.Format("  Reminder: {0}", task.Reminder));
                }
                sb.AppendLine(string.Format("\nTotal: {0} | Pending: {1}", _taskService.GetTaskCount(), _taskService.GetPendingCount()));
                return sb.ToString().Trim();
            }

            if (lower.Contains("remind me") || lower.Contains("set a reminder") ||
                lower.Contains("set reminder"))
            {
                _awaitingTaskTitle = true;
                _logService.Log("Reminder request detected via NLP");
                return "Sure! What task would you like to set a reminder for?";
            }

            if (lower.Contains("quiz") || lower.Contains("test me") ||
                lower.Contains("game") || lower.Contains("start quiz"))
            {
                _logService.Log("Quiz opened via NLP");
                Dispatcher.Invoke(() => OpenQuizWindow());
                return null;
            }

            if (lower.Contains("activity log") || lower.Contains("show log") ||
                lower.Contains("what have you done") || lower.Contains("recent actions"))
            {
                _logService.Log("Activity log requested via NLP");
                return "Activity Log:\n\n" + _logService.GetLogSummary();
            }

            if (lower.Contains("task assistant") || lower.Contains("manage tasks"))
            {
                _logService.Log("Task Assistant opened via NLP");
                Dispatcher.Invoke(() => OpenTaskWindow());
                return null;
            }

            return null;
        }

        private string ExtractAfterKeyword(string lower, string original, string[] keywords)
        {
            foreach (string kw in keywords)
            {
                int idx = lower.IndexOf(kw);
                if (idx >= 0)
                {
                    string after = original.Substring(idx + kw.Length).Trim();
                    after = after.TrimStart('-', ':', ' ');
                    if (after.Length > 2) return after;
                }
            }
            return string.Empty;
        }

        private void AppendUserMessage(string text)
        {
            Dispatcher.Invoke(new Action(() =>
            {
                string name = _engine.UserName == "friend" ? "You" : _engine.UserName;
                ChatPanel.Children.Add(new ChatBubble(text, isUser: true, senderLabel: name));
                ScrollToBottom();
            }));
        }

        private void AppendBotMessage(string text)
        {
            Dispatcher.Invoke(new Action(() =>
            {
                var bubble = new ChatBubble(text, isUser: false, senderLabel: "CyberGuard");
                bubble.Opacity = 0;
                ChatPanel.Children.Add(bubble);
                var anim = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(300));
                bubble.BeginAnimation(OpacityProperty, anim);
                ScrollToBottom();
            }));
        }

        private void ScrollToBottom()
        {
            ChatScrollViewer.UpdateLayout();
            ChatScrollViewer.ScrollToBottom();
        }

        private void UpdateSidebarDirect()
        {
            Dispatcher.Invoke(new Action(() =>
            {
                LblUserName.Text = _engine.UserName == "friend" ? "Not set" : _engine.UserName;
                LblUserInterest.Text = string.IsNullOrEmpty(_engine.UserInterest) ? "None" : _engine.UserInterest;
            }));
        }

        private void OnSentimentDetected(string sentiment, string topic)
        {
            Dispatcher.Invoke(new Action(() =>
            {
                ConsoleUI.UpdateMood(MoodEmoji, MoodLabel, sentiment);
                _logService.Log(string.Format("Sentiment detected: {0}", sentiment));
            }));
        }

        private void BtnVoice_Click(object sender, RoutedEventArgs e)
        {
            _voiceEnabled = !_voiceEnabled;
            _voice.IsEnabled = _voiceEnabled;
            BtnVoice.Content = _voiceEnabled ? "Voice On" : "Voice Off";
            ConsoleUI.ShowStatus(StatusBar, _voiceEnabled ? "Voice enabled." : "Voice disabled.");
            _logService.Log(_voiceEnabled ? "Voice enabled" : "Voice disabled");
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ConsoleUI.ClearChat(ChatPanel);
            AppendBotMessage("Chat cleared! How can I help you today?");
            _logService.Log("Chat cleared");
        }

        private void BtnHelp_Click(object sender, RoutedEventArgs e) => SendMessage("help");

        private void InputBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            InputPlaceholder.Visibility =
                string.IsNullOrEmpty(InputBox.Text) ? Visibility.Visible : Visibility.Collapsed;
        }

        public void Dispose()
        {
            if (!_disposed) { _voice.Dispose(); _disposed = true; }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Dispose();
        }
    }
}