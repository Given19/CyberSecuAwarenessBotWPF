﻿using System.Windows;
using System.Windows.Controls;
using CyberSecuAwarenessBotWPF.Models;
using CyberSecuAwarenessBotWPF.Services;

namespace CyberSecuAwarenessBotWPF.Views
{
    public partial class TaskWindow : Window
    {
        private readonly TaskService _taskService;
        private readonly ActivityLogService _logService;
        private TaskItem _selectedTask;

        public TaskWindow(TaskService taskService, ActivityLogService logService)
        {
            InitializeComponent();
            _taskService = taskService;
            _logService = logService;
            RefreshTaskList();
        }

        private void RefreshTaskList()
        {
            TaskListBox.ItemsSource = null;
            TaskListBox.ItemsSource = _taskService.GetAllTasks();
            FooterText.Text = string.Format("Total: {0} tasks | Pending: {1}",
                _taskService.GetTaskCount(), _taskService.GetPendingCount());
        }

        private void AddTaskBtn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleBox.Text))
            {
                StatusText.Foreground = System.Windows.Media.Brushes.Red;
                StatusText.Text = "Please enter a task title!";
                return;
            }
            var task = _taskService.AddTask(
                TitleBox.Text.Trim(),
                DescriptionBox.Text.Trim(),
                ReminderBox.Text.Trim(),
                ReminderDatePicker.SelectedDate);

            _logService.Log(string.Format("Task added: '{0}'", task.Title));
            if (ReminderDatePicker.SelectedDate.HasValue)
                _logService.Log(string.Format("Reminder set for '{0}' on {1}",
                    task.Title, ReminderDatePicker.SelectedDate.Value.ToShortDateString()));

            TitleBox.Text = string.Empty;
            DescriptionBox.Text = string.Empty;
            ReminderBox.Text = string.Empty;
            ReminderDatePicker.SelectedDate = null;

            StatusText.Foreground = System.Windows.Media.Brushes.LimeGreen;
            StatusText.Text = string.Format("Task '{0}' added!", task.Title);
            RefreshTaskList();
        }

        private void CompleteTaskBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedTask == null)
            {
                StatusText.Foreground = System.Windows.Media.Brushes.Red;
                StatusText.Text = "Please select a task first!";
                return;
            }
            _taskService.CompleteTask(_selectedTask.Id);
            _logService.Log(string.Format("Task completed: '{0}'", _selectedTask.Title));
            StatusText.Foreground = System.Windows.Media.Brushes.LimeGreen;
            StatusText.Text = string.Format("Task '{0}' completed!", _selectedTask.Title);
            RefreshTaskList();
        }

        private void DeleteTaskBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedTask == null)
            {
                StatusText.Foreground = System.Windows.Media.Brushes.Red;
                StatusText.Text = "Please select a task first!";
                return;
            }
            string title = _selectedTask.Title;
            _taskService.DeleteTask(_selectedTask.Id);
            _logService.Log(string.Format("Task deleted: '{0}'", title));
            StatusText.Foreground = System.Windows.Media.Brushes.LimeGreen;
            StatusText.Text = string.Format("Task '{0}' deleted!", title);
            RefreshTaskList();
        }

        private void TaskListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedTask = TaskListBox.SelectedItem as TaskItem;
        }
    }
}