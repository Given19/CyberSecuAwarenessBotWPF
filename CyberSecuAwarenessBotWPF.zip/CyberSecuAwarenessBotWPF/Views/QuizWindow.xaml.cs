﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using CyberSecuAwarenessBotWPF.Services;

namespace CyberSecuAwarenessBotWPF.Views
{
    public partial class QuizWindow : Window
    {
        private readonly QuizService _quizService;
        private readonly ActivityLogService _logService;

        public QuizWindow(ActivityLogService logService)
        {
            InitializeComponent();
            _logService = logService;
            _quizService = new QuizService();
            _logService.Log("Quiz started");
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            if (_quizService.IsFinished) { ShowResults(); return; }

            var q = _quizService.GetCurrentQuestion();
            ProgressText.Text = string.Format("Question {0} of {1}", _quizService.CurrentIndex + 1, _quizService.TotalQuestions);
            ProgressBar.Value = _quizService.CurrentIndex;
            QuestionText.Text = q.Question;
            ScoreText.Text = string.Format("Score: {0}/{1}", _quizService.Score, _quizService.CurrentIndex);
            FeedbackBorder.Visibility = Visibility.Collapsed;

            OptionsPanel.Children.Clear();
            for (int i = 0; i < q.Options.Count; i++)
            {
                int idx = i;
                var btn = new Button
                {
                    Content = string.Format("{0}) {1}", (char)('A' + i), q.Options[i]),
                    Height = 40,
                    Margin = new Thickness(0, 0, 0, 6),
                    Background = new SolidColorBrush(Color.FromRgb(0x21, 0x26, 0x2D)),
                    Foreground = new SolidColorBrush(Color.FromRgb(0xE6, 0xED, 0xF3)),
                    BorderThickness = new Thickness(1),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(0x30, 0x36, 0x3D)),
                    FontSize = 12,
                    Cursor = System.Windows.Input.Cursors.Hand,
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    Padding = new Thickness(10, 0, 0, 0)
                };
                btn.Click += (s, e) => HandleAnswer(idx);
                OptionsPanel.Children.Add(btn);
            }
        }

        private void HandleAnswer(int idx)
        {
            bool correct = _quizService.SubmitAnswer(idx);
            string explanation = _quizService.GetCurrentExplanation();

            foreach (Button btn in OptionsPanel.Children)
                btn.IsEnabled = false;

            FeedbackBorder.Visibility = Visibility.Visible;
            if (correct)
            {
                FeedbackBorder.Background = new SolidColorBrush(Color.FromRgb(0x0D, 0x4A, 0x1E));
                FeedbackText.Text = "Correct! " + explanation;
                FeedbackText.Foreground = new SolidColorBrush(Color.FromRgb(0x39, 0xD3, 0x53));
            }
            else
            {
                FeedbackBorder.Background = new SolidColorBrush(Color.FromRgb(0x3D, 0x0D, 0x0D));
                FeedbackText.Text = "Incorrect. " + explanation;
                FeedbackText.Foreground = new SolidColorBrush(Color.FromRgb(0xF8, 0x51, 0x49));
            }

            var nextBtn = new Button
            {
                Content = _quizService.IsFinished ? "See Results" : "Next Question",
                Height = 36,
                Margin = new Thickness(0, 8, 0, 0),
                Background = new SolidColorBrush(Color.FromRgb(0x39, 0xD3, 0x53)),
                Foreground = new SolidColorBrush(Color.FromRgb(0x0D, 0x11, 0x17)),
                FontWeight = FontWeights.Bold,
                BorderThickness = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                FontSize = 13
            };
            nextBtn.Click += (s, e) => ShowQuestion();
            OptionsPanel.Children.Add(nextBtn);
        }

        private void ShowResults()
        {
            string feedback = _quizService.GetFeedback();
            _logService.Log(string.Format("Quiz completed — Score: {0}/{1}", _quizService.Score, _quizService.TotalQuestions));

            QuestionText.Text = feedback;
            QuestionText.FontSize = 15;
            QuestionText.Foreground = new SolidColorBrush(Color.FromRgb(0x39, 0xD3, 0x53));
            OptionsPanel.Children.Clear();
            FeedbackBorder.Visibility = Visibility.Collapsed;
            ProgressText.Text = "Quiz Complete!";
            ProgressBar.Value = _quizService.TotalQuestions;
            ScoreText.Text = string.Format("Final Score: {0}/{1}", _quizService.Score, _quizService.TotalQuestions);

            var restartBtn = new Button
            {
                Content = "Play Again",
                Height = 40,
                Margin = new Thickness(0, 12, 0, 0),
                Background = new SolidColorBrush(Color.FromRgb(0x39, 0xD3, 0x53)),
                Foreground = new SolidColorBrush(Color.FromRgb(0x0D, 0x11, 0x17)),
                FontWeight = FontWeights.Bold,
                BorderThickness = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                FontSize = 13
            };
            restartBtn.Click += (s, e) => { _quizService.Reset(); _logService.Log("Quiz restarted"); ShowQuestion(); };

            var closeBtn = new Button
            {
                Content = "Close",
                Height = 40,
                Margin = new Thickness(0, 6, 0, 0),
                Background = new SolidColorBrush(Color.FromRgb(0x21, 0x26, 0x2D)),
                Foreground = new SolidColorBrush(Color.FromRgb(0x58, 0xA6, 0xFF)),
                FontWeight = FontWeights.Bold,
                BorderThickness = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                FontSize = 13
            };
            closeBtn.Click += (s, e) => Close();

            OptionsPanel.Children.Add(restartBtn);
            OptionsPanel.Children.Add(closeBtn);
        }
    }
}